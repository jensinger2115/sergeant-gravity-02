// ## Implementation preserve start class opening. 
// ## Implementation preserve end class opening. 
import ReqHandler;
import HttpServlet;
// ## Implementation preserve start class import. 
// ## Implementation preserve end class import. 

public class MainServlet extends HttpServlet
// ## Implementation preserve start class inheritence. 
// ## Implementation preserve end class inheritence. 

{
    /** Attributes */
    private HashMap<String,ReqHandler> handlers;
    // ## Implementation preserve start class attributes. 
    // ## Implementation preserve end class attributes. 
    // ## Implementation preserve start class associations. 
    // ## Implementation preserve end class associations. 
    /**
     * Operation
     *
     * @param req
     * @param res
     * @return 
     */
    public doGet ( HttpServletRequest req, HttpServletResponse res )
    {
        // ## Implementation preserve start class method.doGet@@@@HttpServletRequest@HttpServletResponse 
        // ## Implementation preserve end class method.doGet@@@@HttpServletRequest@HttpServletResponse 
    }
    /**
     * Operation
     *
     * @param req
     * @param res
     * @return 
     */
    public doPost ( HttpServletRequest req, HttpServletResponse res )
    {
        // ## Implementation preserve start class method.doPost@@@@HttpServletRequest@HttpServletResponse 
        // ## Implementation preserve end class method.doPost@@@@HttpServletRequest@HttpServletResponse 
    }
    /**
     * Operation
     *
     * @param id
     * @param handler
     * @return 
     */
    public addReqHandler ( String id, ReqHandler handler )
    {
        // ## Implementation preserve start class method.addReqHandler@@@@String@ReqHandler 
        // ## Implementation preserve end class method.addReqHandler@@@@String@ReqHandler 
    }
    /**
     * Operation
     *
     * @param id
     * @param handler
     * @return 
     */
    public removeReqHandler ( String id, ReqHandler handler )
    {
        // ## Implementation preserve start class method.removeReqHandler@@@@String@ReqHandler 
        // ## Implementation preserve end class method.removeReqHandler@@@@String@ReqHandler 
    }
    /**
     * Operation
     *
     * @return 
     */
    public removeAll (  )
    {
        // ## Implementation preserve start class method.removeAll@@@ 
        // ## Implementation preserve end class method.removeAll@@@ 
    }
    /**
     * Operation
     *
     * @param req
     * @param res
     * @return 
     */
    public doDelete ( HttpServletRequest req, HttpServletResponse res )
    {
        // ## Implementation preserve start class method.doDelete@@@@HttpServletRequest@HttpServletResponse 
        // ## Implementation preserve end class method.doDelete@@@@HttpServletRequest@HttpServletResponse 
    }
    // ## Implementation preserve start class other.operations. 
    // ## Implementation preserve end class other.operations. 
}

// ## Implementation preserve start class closing. 
// ## Implementation preserve end class closing. 
