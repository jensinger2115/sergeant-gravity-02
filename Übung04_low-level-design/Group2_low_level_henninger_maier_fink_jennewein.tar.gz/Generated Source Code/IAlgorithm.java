// ## Implementation preserve start class opening. 
// ## Implementation preserve end class opening. 
import DataSet;
// ## Implementation preserve start class import. 
// ## Implementation preserve end class import. 

public interface IAlgorithm
// ## Implementation preserve start class extends. 
// ## Implementation preserve end class extends. 

// ## Implementation preserve start class inheritence. 
// ## Implementation preserve end class inheritence. 

{
    // ## Implementation preserve start class associations. 
    // ## Implementation preserve end class associations. 
    /**
     * Operation
     *
     * @param data
     * @return DataSet
     */
    public DataSet calculate ( DataSet data );
}

// ## Implementation preserve start class closing. 
// ## Implementation preserve end class closing. 
