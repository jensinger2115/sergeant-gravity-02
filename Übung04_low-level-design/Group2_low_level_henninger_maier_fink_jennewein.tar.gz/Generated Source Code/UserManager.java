// ## Implementation preserve start class opening. 
// ## Implementation preserve end class opening. 
import UserManager;
import DataAccessor;
import User;
// ## Implementation preserve start class import. 
// ## Implementation preserve end class import. 

public class UserManager
// ## Implementation preserve start class extends. 
// ## Implementation preserve end class extends. 

// ## Implementation preserve start class inheritence. 
// ## Implementation preserve end class inheritence. 

{
    /** Attributes */
    private UserManager userManager;
    protected DataAccessor dataAccessor;
    // ## Implementation preserve start class attributes. 
    // ## Implementation preserve end class attributes. 
    // ## Implementation preserve start class associations. 
    // ## Implementation preserve end class associations. 
    /**
     * Operation
     *
     * @return UserManager
     */
    public UserManager getInstance (  )
    {
        // ## Implementation preserve start class method.getInstance@UserManager@@ 
        // ## Implementation preserve end class method.getInstance@UserManager@@ 
    }
    /**
     * Operation
     *
     * @param userId
     * @param password
     * @return User
     */
    public User verify ( String userId, String password )
    {
        // ## Implementation preserve start class method.verify@User@@@String@String 
        // ## Implementation preserve end class method.verify@User@@@String@String 
    }
    /**
     * Operation
     *
     * @param userId
     * @return User
     */
    public User load ( String userId )
    {
        // ## Implementation preserve start class method.load@User@@@String 
        // ## Implementation preserve end class method.load@User@@@String 
    }
    /**
     * Operation
     *
     * @param userId
     * @param password
     * @return 
     */
    public newU ( String userId, String password )
    {
        // ## Implementation preserve start class method.newU@@@@String@String 
        // ## Implementation preserve end class method.newU@@@@String@String 
    }
    /**
     * Operation
     *
     * @param groupId
     * @param creatorId
     * @return 
     */
    public newGroup ( String groupId, String creatorId )
    {
        // ## Implementation preserve start class method.newGroup@@@@String@String 
        // ## Implementation preserve end class method.newGroup@@@@String@String 
    }
    /**
     * Operation
     *
     * @param user
     * @return 
     */
    public modify ( User user )
    {
        // ## Implementation preserve start class method.modify@@@@User 
        // ## Implementation preserve end class method.modify@@@@User 
    }
    /**
     * Operation
     *
     * @param userId
     * @return 
     */
    public delete ( String userId )
    {
        // ## Implementation preserve start class method.delete@@@@String 
        // ## Implementation preserve end class method.delete@@@@String 
    }
    /** Constructor *
     * Operation
     *
     * @param 
     * @return 
     */
    private UserManager (   )
    {
        // ## Implementation preserve start class method.UserManager@@@@ 
        // ## Implementation preserve end class method.UserManager@@@@ 
    }
    // ## Implementation preserve start class other.operations. 
    // ## Implementation preserve end class other.operations. 
}

// ## Implementation preserve start class closing. 
// ## Implementation preserve end class closing. 
