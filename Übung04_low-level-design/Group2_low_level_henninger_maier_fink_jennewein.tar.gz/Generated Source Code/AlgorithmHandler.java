// ## Implementation preserve start class opening. 
// ## Implementation preserve end class opening. 
import DataSet;
import IAlgorithm;
import DataHandler;
import NewAlgorithm;
// ## Implementation preserve start class import. 
// ## Implementation preserve end class import. 

public class AlgorithmHandler extends DataHandler
// ## Implementation preserve start class inheritence. 
// ## Implementation preserve end class inheritence. 

{
    /** Attributes */
    private AlgMeta algMeta;
    // ## Implementation preserve start class attributes. 
    // ## Implementation preserve end class attributes. 
    /**
     * Operation
     *
     * @param req
     * @param res
     * @return 
     */
    public handle ( HttpServletRequest req, HttpServletResponse res )
    {
        // ## Implementation preserve start class method.handle@@@@HttpServletRequest@HttpServletResponse 
        // ## Implementation preserve end class method.handle@@@@HttpServletRequest@HttpServletResponse 
    }
    /**
     * Operation
     *
     * @param data
     * @param algorithm
     * @return 
     */
    public doAlg ( DataSet data, String algorithm )
    {
        // ## Implementation preserve start class method.doAlg@@@@DataSet@String 
        // ## Implementation preserve end class method.doAlg@@@@DataSet@String 
    }
    /**
     * Operation
     *
     * @return boolean
     */
    public boolean abort (  )
    {
        // ## Implementation preserve start class method.abort@boolean@@ 
        // ## Implementation preserve end class method.abort@boolean@@ 
    }
    /**
     * Operation
     *
     * @return IAlgorithm
     */
    public IAlgorithm createAlgorithm (  )
    {
        // ## Implementation preserve start class method.createAlgorithm@IAlgorithm@@ 
        // ## Implementation preserve end class method.createAlgorithm@IAlgorithm@@ 
    }
    // ## Implementation preserve start class other.operations. 
    // ## Implementation preserve end class other.operations. 
}

// ## Implementation preserve start class closing. 
// ## Implementation preserve end class closing. 
