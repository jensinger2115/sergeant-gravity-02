// ## Implementation preserve start class opening. 
// ## Implementation preserve end class opening. 
import DataSet;
import DataHandler;
// ## Implementation preserve start class import. 
// ## Implementation preserve end class import. 

public class DownloadHandler extends DataHandler
// ## Implementation preserve start class inheritence. 
// ## Implementation preserve end class inheritence. 

{
    // ## Implementation preserve start class attributes. 
    // ## Implementation preserve end class attributes. 
    // ## Implementation preserve start class associations. 
    // ## Implementation preserve end class associations. 
    /**
     * Operation
     *
     * @param req
     * @param res
     * @return 
     */
    public handle ( HttpServletRequest req, HttpServletResponse res )
    {
        // ## Implementation preserve start class method.handle@@@@HttpServletRequest@HttpServletResponse 
        // ## Implementation preserve end class method.handle@@@@HttpServletRequest@HttpServletResponse 
    }
    /**
     * Operation
     *
     * @param data
     * @return 
     */
    public download ( DataSet data )
    {
        // ## Implementation preserve start class method.download@@@@DataSet 
        // ## Implementation preserve end class method.download@@@@DataSet 
    }
    // ## Implementation preserve start class other.operations. 
    // ## Implementation preserve end class other.operations. 
}

// ## Implementation preserve start class closing. 
// ## Implementation preserve end class closing. 
