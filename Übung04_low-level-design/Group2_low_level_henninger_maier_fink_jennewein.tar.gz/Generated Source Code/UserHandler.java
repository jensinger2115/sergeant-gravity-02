// ## Implementation preserve start class opening. 
// ## Implementation preserve end class opening. 
import UserManager;
import ReqHandler;
// ## Implementation preserve start class import. 
// ## Implementation preserve end class import. 

public class UserHandler
// ## Implementation preserve start class extends. 
// ## Implementation preserve end class extends. 
 implements ReqHandler
// ## Implementation preserve start class inheritence. 
// ## Implementation preserve end class inheritence. 

{
    /** Attributes */
    protected UserManager userManager;
    // ## Implementation preserve start class attributes. 
    // ## Implementation preserve end class attributes. 
    // ## Implementation preserve start class other.operations. 
    // ## Implementation preserve end class other.operations. 
}

// ## Implementation preserve start class closing. 
// ## Implementation preserve end class closing. 
