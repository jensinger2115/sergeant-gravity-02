// ## Implementation preserve start class opening. 
// ## Implementation preserve end class opening. 
import DataHandler;
// ## Implementation preserve start class import. 
// ## Implementation preserve end class import. 

public class DeleteHandler extends DataHandler
// ## Implementation preserve start class inheritence. 
// ## Implementation preserve end class inheritence. 

{
    // ## Implementation preserve start class attributes. 
    // ## Implementation preserve end class attributes. 
    // ## Implementation preserve start class associations. 
    // ## Implementation preserve end class associations. 
    /**
     * Operation
     *
     * @param req
     * @param res
     * @return 
     */
    public handle ( HttpServletRequest req, HttpServletResponse res )
    {
        // ## Implementation preserve start class method.handle@@@@HttpServletRequest@HttpServletResponse 
        // ## Implementation preserve end class method.handle@@@@HttpServletRequest@HttpServletResponse 
    }
    /**
     * Operation
     *
     * @param dataId
     * @param userId
     * @return 
     */
    public delete ( String dataId, String userId )
    {
        // ## Implementation preserve start class method.delete@@@@String@String 
        // ## Implementation preserve end class method.delete@@@@String@String 
    }
    // ## Implementation preserve start class other.operations. 
    // ## Implementation preserve end class other.operations. 
}

// ## Implementation preserve start class closing. 
// ## Implementation preserve end class closing. 
