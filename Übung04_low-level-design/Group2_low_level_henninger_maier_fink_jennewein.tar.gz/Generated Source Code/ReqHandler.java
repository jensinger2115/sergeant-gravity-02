// ## Implementation preserve start class opening. 
// ## Implementation preserve end class opening. 
import MainServlet;
// ## Implementation preserve start class import. 
// ## Implementation preserve end class import. 

public interface ReqHandler
// ## Implementation preserve start class extends. 
// ## Implementation preserve end class extends. 

// ## Implementation preserve start class inheritence. 
// ## Implementation preserve end class inheritence. 

{
    /**
     * Operation
     *
     * @param req
     * @param res
     * @return 
     */
    public handle ( HttpServletRequest req, HttpServletResponse res );
}

// ## Implementation preserve start class closing. 
// ## Implementation preserve end class closing. 
