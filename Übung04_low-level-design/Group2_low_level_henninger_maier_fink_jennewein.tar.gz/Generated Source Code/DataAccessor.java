// ## Implementation preserve start class opening. 
// ## Implementation preserve end class opening. 
import Packet;
import UserManager;
import DataManager;
// ## Implementation preserve start class import. 
// ## Implementation preserve end class import. 

public class DataAccessor
// ## Implementation preserve start class extends. 
// ## Implementation preserve end class extends. 

// ## Implementation preserve start class inheritence. 
// ## Implementation preserve end class inheritence. 

{
    // ## Implementation preserve start class attributes. 
    // ## Implementation preserve end class attributes. 
    /** Associations */
    private UserManager userManager;
    private DataManager dataManager;
    // ## Implementation preserve start class associations. 
    // ## Implementation preserve end class associations. 
    /**
     * Operation
     *
     * @param dataID
     * @return 
     */
    public getData ( String dataID, String userId )
    {
        // ## Implementation preserve start class method.getData@@@@String 
        // ## Implementation preserve end class method.getData@@@@String 
    }
    /**
     * Operation
     *
     * @param dataID
     * @return 
     */
    public Packet deleteData ( String dataID, String userId )
    {
        // ## Implementation preserve start class method.deleteData@@@@String 
        // ## Implementation preserve end class method.deleteData@@@@String 
	
    }
    /**
     * Operation
     *
     * @param packet
     * @return 
     */
    public saveData ( Packet packet )
    {
        // ## Implementation preserve start class method.saveData@@@@Packet 
        // ## Implementation preserve end class method.saveData@@@@Packet 
    }
    // ## Implementation preserve start class other.operations. 
    // ## Implementation preserve end class other.operations. 

    public User load(String userId){

    }

    public saveU(User user){

    }

    public saveGroup(UserGroup group){

    }

    public deleteUG(String id){

    }
}

// ## Implementation preserve start class closing. 
// ## Implementation preserve end class closing. 
