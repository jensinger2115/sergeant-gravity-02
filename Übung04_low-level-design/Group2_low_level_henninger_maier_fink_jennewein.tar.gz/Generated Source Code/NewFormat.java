// ## Implementation preserve start class opening. 
// ## Implementation preserve end class opening. 
import DataSet;
import IFormat;
// ## Implementation preserve start class import. 
// ## Implementation preserve end class import. 

public class NewFormat extends IFormat
// ## Implementation preserve start class inheritence. 
// ## Implementation preserve end class inheritence. 

{
    /** Attributes */
    public String name;
    // ## Implementation preserve start class attributes. 
    // ## Implementation preserve end class attributes. 
    // ## Implementation preserve start class associations. 
    // ## Implementation preserve end class associations. 
    /**
     * Operation
     *
     * @param data
     * @return 
     */
    public convert ( DataSet data )
    {
        // ## Implementation preserve start class method.convert@@@@DataSet 
        // ## Implementation preserve end class method.convert@@@@DataSet 
    }
    // ## Implementation preserve start class other.operations. 
    // ## Implementation preserve end class other.operations. 
}

// ## Implementation preserve start class closing. 
// ## Implementation preserve end class closing. 
