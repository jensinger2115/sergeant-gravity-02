// ## Implementation preserve start class opening. 
// ## Implementation preserve end class opening. 
import Converter;
import DataSet;
import NewFormat;
// ## Implementation preserve start class import. 
// ## Implementation preserve end class import. 

public class Converter
// ## Implementation preserve start class extends. 
// ## Implementation preserve end class extends. 

// ## Implementation preserve start class inheritence. 
// ## Implementation preserve end class inheritence. 

{
    /** Attributes */
    private Converter converter;
    private ConvMeta convMeta;
    // ## Implementation preserve start class attributes. 
    // ## Implementation preserve end class attributes. 
    /**
     * Operation
     *
     * @return Converter
     */
    public Converter getInstance (  )
    {
        // ## Implementation preserve start class method.getInstance@Converter@@ 
        // ## Implementation preserve end class method.getInstance@Converter@@ 
    }
    /**
     * Operation
     *
     * @param data
     * @param format
     * @return 
     */
    public convert ( DataSet data, String format )
    {
        // ## Implementation preserve start class method.convert@@@@DataSet@String 
        // ## Implementation preserve end class method.convert@@@@DataSet@String 
    }
    /**
     * Operation
     *
     * @param format
     * @return boolean
     */
    public boolean isSupported ( String format )
    {
        // ## Implementation preserve start class method.isSupported@boolean@@@String 
        // ## Implementation preserve end class method.isSupported@boolean@@@String 
    }
    /**
     * Operation
     *
     * @return NewFormat
     */
    public NewFormat createFormat (  )
    {
        // ## Implementation preserve start class method.createFormat@NewFormat@@ 
        // ## Implementation preserve end class method.createFormat@NewFormat@@ 
    }
    /**
     * Operation
     *
     * @return 
     */
    private Converter (  )
    {
        // ## Implementation preserve start class method.Converter@@@ 
        // ## Implementation preserve end class method.Converter@@@ 
    }
    // ## Implementation preserve start class other.operations. 
    // ## Implementation preserve end class other.operations. 
}

// ## Implementation preserve start class closing. 
// ## Implementation preserve end class closing. 
