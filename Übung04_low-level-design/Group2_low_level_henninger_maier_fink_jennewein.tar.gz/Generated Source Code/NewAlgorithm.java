// ## Implementation preserve start class opening. 
// ## Implementation preserve end class opening. 
import DataSet;
import IAlgorithm;
// ## Implementation preserve start class import. 
// ## Implementation preserve end class import. 

public class NewAlgorithm
// ## Implementation preserve start class extends. 
// ## Implementation preserve end class extends. 
 implements IAlgorithm
// ## Implementation preserve start class inheritence. 
// ## Implementation preserve end class inheritence. 

{
    // ## Implementation preserve start class attributes. 
    // ## Implementation preserve end class attributes. 
    // ## Implementation preserve start class associations. 
    // ## Implementation preserve end class associations. 
    /**
     * Operation
     *
     * @param data
     * @return DataSet
     */
    public DataSet calculate ( DataSet data )
    {
        // ## Implementation preserve start class method.calculate@DataSet@@@DataSet 
        // ## Implementation preserve end class method.calculate@DataSet@@@DataSet 
    }
    // ## Implementation preserve start class other.operations. 
    // ## Implementation preserve end class other.operations. 
}

// ## Implementation preserve start class closing. 
// ## Implementation preserve end class closing. 
