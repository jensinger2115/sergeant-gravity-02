// ## Implementation preserve start class opening. 
// ## Implementation preserve end class opening. 
import MainServlet;
// ## Implementation preserve start class import. 
// ## Implementation preserve end class import. 

public class RestHandler
// ## Implementation preserve start class extends. 
// ## Implementation preserve end class extends. 

// ## Implementation preserve start class inheritence. 
// ## Implementation preserve end class inheritence. 

{
    /** Attributes */
    private MainServlet mainServlet;
    // ## Implementation preserve start class attributes. 
    // ## Implementation preserve end class attributes.  
    /**
     * Operation
     *
     * @param req
     * @param res
     * @return 
     */
    public get ( HttpServletRequest req, HttpServletResponse res )
    {
        // ## Implementation preserve start class method.get@@@@HttpServletRequest@HttpServletResponse 
        // ## Implementation preserve end class method.get@@@@HttpServletRequest@HttpServletResponse 
    }
    /**
     * Operation
     *
     * @param req
     * @param res
     * @return 
     */
    public post ( HttpServletRequest req, HttpServletResponse res )
    {
        // ## Implementation preserve start class method.post@@@@HttpServletRequest@HttpServletResponse 
        // ## Implementation preserve end class method.post@@@@HttpServletRequest@HttpServletResponse 
    }
    /**
     * Operation
     *
     * @param req
     * @param res
     * @return 
     */
    public delete ( HttpServletRequest req, HttpServletResponse res )
    {
        // ## Implementation preserve start class method.delete@@@@HttpServletRequest@HttpServletResponse 
        // ## Implementation preserve end class method.delete@@@@HttpServletRequest@HttpServletResponse 
    }
    /**
     * Operation
     *
     * @return HttpServletResponse
     */
    public HttpServletResponse response (  )
    {
        // ## Implementation preserve start class method.response@HttpServletResponse@@ 
        // ## Implementation preserve end class method.response@HttpServletResponse@@ 
    }
    // ## Implementation preserve start class other.operations. 
    // ## Implementation preserve end class other.operations. 
}

// ## Implementation preserve start class closing. 
// ## Implementation preserve end class closing. 
