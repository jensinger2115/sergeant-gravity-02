// ## Implementation preserve start class opening. 
// ## Implementation preserve end class opening. 
import UserHandler;
// ## Implementation preserve start class import. 
// ## Implementation preserve end class import. 

public class UserAreaHandler extends UserHandler
// ## Implementation preserve start class inheritence. 
// ## Implementation preserve end class inheritence. 

{
    // ## Implementation preserve start class attributes. 
    // ## Implementation preserve end class attributes. 
    // ## Implementation preserve start class associations. 
    // ## Implementation preserve end class associations. 
    /**
     * Operation
     *
     * @param req
     * @param res
     * @return 
     */
    public handle ( HttpServletRequest req, HttpServletResponse res )
    {
        // ## Implementation preserve start class method.handle@@@@HttpServletRequest@HttpServletResponse 
        // ## Implementation preserve end class method.handle@@@@HttpServletRequest@HttpServletResponse 
    }
    /**
     * Operation
     *
     * @param userId
     * @param session
     * @return 
     */
    public showUserArea ( String userId, HttpSession session )
    {
        // ## Implementation preserve start class method.showUserArea@@@@String@HttpSession 
        // ## Implementation preserve end class method.showUserArea@@@@String@HttpSession 
    }
    /**
     * Operation
     *
     * @param userId
     * @param photo
     * @return 
     */
    public addPhoto ( String userId, Image photo )
    {
        // ## Implementation preserve start class method.addPhoto@@@@String@Image 
        // ## Implementation preserve end class method.addPhoto@@@@String@Image 
    }
    /**
     * Operation
     *
     * @param groupId
     * @param creatorId
     * @return 
     */
    public createGroup ( String groupId, String creatorId )
    {
        // ## Implementation preserve start class method.createGroup@@@@String@String 
        // ## Implementation preserve end class method.createGroup@@@@String@String 
    }
    /**
     * Operation
     *
     * @param userId
     * @param groupId
     * @param inviteId
     * @return 
     */
    public invite ( String userId, String groupId, String inviteId )
    {
        // ## Implementation preserve start class method.invite@@@@String@String@String 
        // ## Implementation preserve end class method.invite@@@@String@String@String 
    }
    // ## Implementation preserve start class other.operations. 
    // ## Implementation preserve end class other.operations. 
}

// ## Implementation preserve start class closing. 
// ## Implementation preserve end class closing. 
